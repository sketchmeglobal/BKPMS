<footer class="bg-light footer text-center">
    With Gratitude || <a target="_new" href="https://sketchmeglobal.com/">Sketch Me Global</a>.
</footer>