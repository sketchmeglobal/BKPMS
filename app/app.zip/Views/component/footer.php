<div class="container-fluid pt-4 px-4">
    <div class="bg-light rounded-top p-4">
        <div class="row">
            <div class="col-12 col-sm-6 text-center text-sm-start">
                &copy; <?=date('Y')?> <a href="javascript:;">Baazar Kolkata</a>, All Right Reserved.
            </div>
            <div class="col-12 col-sm-6 text-center text-sm-end">
                            <span data-toggle="tooltip" data-placement="top" title="Sketch Me Global">
                                Powered by <a class="border-bottom" href="https://sketchmeglobal.com" target="_blank">SMG</a>
                            </span>
            </div>
        </div>
    </div>
</div>

        </div>
        <!-- Content End -->


        <!-- Back to Top -->
        <a href="#" class="btn btn-lg btn-primary btn-lg-square back-to-top"><i class="bi bi-arrow-up"></i></a>

    </div>

    </body>

</html>