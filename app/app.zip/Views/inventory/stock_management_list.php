    <?= view('component/main_header') ?>
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.css" />
    <style>
/* .card {
    border-left: 4px solid #f7f7f7;
} */

label {
    color: #000
}
    </style>
    </head>
    <?php #echo '<pre>', print_r($approved_menu), '</pre>'; ?>

    <body>

        <!-- validation and notification area -->
        <!-- <div class="d-none" id="validation_error"></div> -->

        <div class="preloader">
            <div class="lds-ripple">
                <div class="lds-pos"></div>
                <div class="lds-pos"></div>
            </div>
        </div>

        <div id="main-wrapper">

            <?= view('component/main_top_nav') ?>
            <?= view('component/main_side_nav') ?>

            <div class="page-wrapper">
                <div class="page-breadcrumb">
                    <div class="row">
                        <div class="col-5 align-self-center">
                            <h4 class="page-title">Stock Management</h4>
                        </div>
                        <div class="col-7 align-self-center">
                            <div class="d-flex align-items-center justify-content-end">
                                <nav aria-label="breadcrumb">
                                    <ol class="breadcrumb">
                                        <li class="breadcrumb-item">
                                            <a href="<?=base_url('portal/dashboard')?>">Home</a>
                                        </li>
                                        <li class="breadcrumb-item active" aria-current="page">Stock Management List
                                        </li>
                                    </ol>
                                </nav>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="container-fluid">
                    <div class="row">
                        <div class="col-12">
                            <div class="card">
                                <div class="card-body">
                                    <h4 class="card-title">
                                        <a data-toggle="modal" data-target="#addModal" class="btn btn-sm btn-success"
                                            href="<?=base_url('portal/add-cm-list')?>"> <i class="mdi mdi-plus"></i>
                                            Add</a>
                                    </h4>
                                    <div class="table-responsive">
                                        <table id="sm_list_table" class="table table-striped table-bordered">
                                            <thead>
                                                <tr>
                                                    <th>#</th>
                                                    <th>Device Name</th>
                                                    <th>Device Serial No</th>
                                                    <th>Action</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php 
                                            if((array)count($sm_list) > 0){ 
                                                foreach($sm_list as $iter=>$smlist){
                                            ?>
                                                <tr>
                                                    <td><?=++$iter?>.</td>
                                                    <td><?=$smlist->hw_name?></td>
                                                    <td><?=$smlist->serial_no?></td>
                                                    <td>
                                                        <a data-pk="<?=$smlist->hw_sl_id?>"
                                                            class="btn btn-sm btn-warning edit"
                                                            href="javascript:void(0)">
                                                            <i class="mdi mdi-table-edit"></i> Edit</a>
                                                        <button data-pk="<?=$smlist->hw_sl_id?>" type="button"
                                                            data-pk="<?=$smlist->hw_sl_id?>"
                                                            class="btn btn-sm btn-danger remove">
                                                            <i class="mdi mdi-minus"></i> Remove</button>
                                                    </td>
                                                </tr>
                                                <?php 
                                                }
                                            } 
                                            ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?= view('component/main_footer') ?>
            </div>

            <!-- Add Modal -->
            <div class="modal fade" id="addModal" tabindex="-1" role="dialog" data-backdrop="static"
                data-keyboard="false" aria-labelledby="addModalLabel1">
                <div class="modal-dialog modal-lg" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h4 class="modal-title" id="exampleModalLabel1">Stock Entry </h4>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span
                                    aria-hidden="true">&times;</span></button>
                        </div>
                        <div class="modal-body">

                            <form id="add_sm_form" class="form-horizontal r-separator" method="post">
                                <div class="card">
                                    <div class="card-body p-0">
                                        <div class="card-body bg-light">
                                            <!--  <h5 class="card-title m-t-10 p-b-20 text-info text-center font-weight-bold">
                                                Reference No</h5> -->
                                            <div class="row border-bottom">
                                                <div class="col-sm-12 col-lg-6">
                                                    <div class="form-group row align-items-center m-b-0">
                                                        <label for="hw_id"
                                                            class="col-3 text-right control-label col-form-label">Device
                                                            Name</label>
                                                        <div class="col-9 border-left p-t-10 p-b-10">
                                                            <select class="form-control" required name="hw_id"
                                                                id="hw_id">
                                                                <option selected disabled value="">Select from the
                                                                    list</option>
                                                                <?php foreach($inventory_category_list as $row){ ?>
                                                                <option value="<?=$row->id?>">
                                                                    <?=$row->hw_name?> (<?=$row->hw_code?>)
                                                                </option>
                                                                <?php } ?>
                                                            </select>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-sm-12 col-lg-6">
                                                    <div class="form-group row align-items-center m-b-0">
                                                        <label for="serial_no"
                                                            class="col-3 text-right control-label col-form-label">Device
                                                            Serial No</label>
                                                        <div class="col-9 border-left p-t-10 p-b-10">
                                                            <input required type="text" class="form-control"
                                                                id="serial_no" name="serial_no"
                                                                placeholder="Enter Here">
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="row mt-2">
                                                <div class="col-sm-12 col-lg-12">
                                                    <div class="table-responsive">
                                                        <table class="table table-striped table-bordered repeater">
                                                            <thead>
                                                                <tr>
                                                                    <th>Custom Label</th>
                                                                    <th>Custom Value</th>
                                                                    <th><button data-repeater-create type="button"
                                                                            class="btn btn-sm btn-success"><i
                                                                                class="mdi mdi-plus"></i> Add</button>
                                                                    </th>
                                                                </tr>
                                                            </thead>
                                                            <tbody data-repeater-list="deviceMetaData">
                                                                <tr data-repeater-item>
                                                                    <td><input type="text" class="form-control"
                                                                            name="label" id="label"></td>
                                                                    <td><input type="text" class="form-control"
                                                                            name="value" id="value"></td>
                                                                    <td> <button data-repeater-delete type="button"
                                                                            class="btn btn-sm btn-danger"><i
                                                                                class="mdi mdi-minus"></i>
                                                                            Remove</button></td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <hr>
                                        <div class="card-footer bg-white">
                                            <div class="form-group m-b-0 text-center">
                                                <button type="submit" class="btn btn-info waves-effect waves-light"
                                                    name="sm_form" value="sm_form">Save</button>
                                                <button type="button" data-dismiss="modal" aria-label="Close"
                                                    class="btn btn-dark waves-effect waves-light">Cancel</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </form>

                        </div>
                    </div>
                </div>
            </div>
            <!-- Edit Modal -->
            <div class="modal fade" id="editModal" tabindex="-1" role="dialog" data-backdrop="static"
                data-keyboard="false" aria-labelledby="addModalLabel1">
                <div class="modal-dialog modal-lg" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h4 class="modal-title" id="exampleModalLabel1"> Stock Edit </h4>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span
                                    aria-hidden="true">&times;</span></button>
                        </div>
                        <div class="modal-body">

                            <form id="edit_sm_form" class="form-horizontal r-separator" method="post">
                                <div class="card">
                                    <div class="card-body p-0">
                                        <div class="card-body bg-light">
                                            <!--  <h5 class="card-title m-t-10 p-b-20 text-info text-center font-weight-bold">
                                                Reference No</h5> -->
                                            <div class="row border-bottom">
                                                <div class="col-sm-12 col-lg-6">
                                                    <div class="form-group row align-items-center m-b-0">
                                                        <label for="hw_id"
                                                            class="col-3 text-right control-label col-form-label">Device
                                                            Name</label>
                                                        <div class="col-9 border-left p-t-10 p-b-10">
                                                            <select class="form-control hw_id" required name="hw_id"
                                                                id="hw_id">
                                                                <option selected disabled value="">Select from the
                                                                    list</option>
                                                                <?php foreach($inventory_category_list as $row){ ?>
                                                                <option value="<?=$row->id?>">
                                                                    <?=$row->hw_name?> (<?=$row->hw_code?>)
                                                                </option>
                                                                <?php } ?>
                                                            </select>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-sm-12 col-lg-6">
                                                    <div class="form-group row align-items-center m-b-0">
                                                        <label for="serial_no"
                                                            class="col-3 text-right control-label col-form-label">Device
                                                            Serial No</label>
                                                        <div class="col-9 border-left p-t-10 p-b-10">
                                                            <input required type="text" class="form-control serial_no"
                                                                id="serial_no" name="serial_no"
                                                                placeholder="Enter Here">
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="row mt-2">
                                                <div class="col-sm-12 col-lg-12">
                                                    <div class="table-responsive">
                                                        <table class="table table-striped table-bordered repeater">
                                                            <thead>
                                                                <tr>
                                                                    <th>Custom Label</th>
                                                                    <th>Custom Value</th>
                                                                    <th><button data-repeater-create type="button"
                                                                            class="btn btn-sm btn-success"><i
                                                                                class="mdi mdi-plus"></i> Add</button>
                                                                    </th>
                                                                </tr>
                                                            </thead>
                                                            <tbody data-repeater-list="deviceMetaData">
                                                                <tr data-repeater-item>
                                                                    <td><input type="text" class="form-control"
                                                                            name="label" id="label"></td>
                                                                    <td><input type="text" class="form-control"
                                                                            name="value" id="value"></td>
                                                                    <td> <button data-repeater-delete type="button"
                                                                            class="btn btn-sm btn-danger"><i
                                                                                class="mdi mdi-minus"></i>
                                                                            Remove</button></td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <hr>
                                        <div class="card-footer bg-white">
                                            <div class="form-group m-b-0 text-center">
                                            <input type="hidden"name="pk_id" id="pk_id">
                                                <button type="submit" class="btn btn-info waves-effect waves-light"
                                                    name="sm_form_edit" value="sm_form_edit">Save</button>
                                                <button type="button" data-dismiss="modal" aria-label="Close"
                                                    class="btn btn-dark waves-effect waves-light">Cancel</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </form>

                        </div>
                    </div>
                </div>
            </div>
        </div>

        <?= view('component/main_scripts') ?>

        <script>
        $(document).ready(function() {

            $('#sm_list_table').DataTable();

            // remove area
            $('.remove').click(function() {
                $this = $(this);
                pid = $(this).data('pk')
                $.ajax({
                    url: "<?= base_url('portal/inventory/ajax-remove-sm-list') ?>",
                    dataType: 'json',
                    type: 'POST',
                    data: {
                        pid: pid
                    },
                    success: function(returnData) {
                        console.log(returnData);
                        $this.closest('tr').remove();
                        toastr.success("Item deleted succesfully", 'Success', {
                            "closeButton": true
                        });
                    },
                    error: function(returnData) {
                        obj = JSON.parse(returnData);
                        console.log(obj);
                        toastr.error("Item deleted succesfully", 'Error', {
                            "closeButton": true
                        });
                    }
                })
            });


            var $repeater = $('.repeater').repeater({
                // (Optional)
                // start with an empty list of repeaters. Set your first (and only)
                // "data-repeater-item" with style="display:none;" and pass the
                // following configuration flag
                //initEmpty: true,
                // (Optional)
                // "defaultValues" sets the values of added items.  The keys of
                // defaultValues refer to the value of the input's name attribute.
                // If a default value is not specified for an input, then it will
                // have its value cleared.
                /* defaultValues: {
                    'text-input': 'foo'
                }, */
                // (Optional)
                // "show" is called just after an item is added.  The item is hidden
                // at this point.  If a show callback is not given the item will
                // have $(this).show() called on it.
                show: function() {
                    $(this).slideDown();
                },
                // (Optional)
                // "hide" is called when a user clicks on a data-repeater-delete
                // element.  The item is still visible.  "hide" is passed a function
                // as its first argument which will properly remove the item.
                // "hide" allows for a confirmation step, to send a delete request
                // to the server, etc.  If a hide callback is not given the item
                // will be deleted.
                hide: function(deleteElement) {
                    if (confirm('Are you sure you want to delete this element?')) {
                        $(this).slideUp(deleteElement);
                    }
                },
                // (Optional)
                // You can use this if you need to manually re-index the list
                // for example if you are using a drag and drop library to reorder
                // list items.
                /* ready: function (setIndexes) {
                    $dragAndDrop.on('drop', setIndexes);
                }, */
                // (Optional)
                // Removes the delete button from the first list item,
                // defaults to false.
                isFirstItemUndeletable: true
            })

            $('#add_sm_form').ajaxForm({
                success: function(res) {
                    res = JSON.parse(res);
                    notification(res);
                    window.location.href = window.location.href;
                }
            });
            // edit area
            $(document).on('click', '.edit', function() {
                $this = $(this);
                pid = $(this).data('pk')
                $.ajax({
                    url: "<?= base_url('portal/inventory/ajax-edit-sm-fetch') ?>",
                    dataType: 'json',
                    type: 'POST',
                    data: {
                        pid: pid
                    },
                    success: function(returnData) {
                        console.log(returnData);
                        $('.serial_no').val(returnData.serial_no);
                        $('#pk_id').val(returnData.hw_sl_id);
                        $(".hw_id").val(returnData.hw_id).change();
                        obj = JSON.parse(returnData.deviceMetaData);
                        console.log(obj);
                        $repeater.setList(obj);
                        $('#editModal').modal('show');
                    },
                    error: function(returnData) {
                        obj = JSON.parse(returnData);
                        console.log(obj);
                    }
                })
            });

            $('#edit_sm_form').ajaxForm({
                success: function(res) {
                    res = JSON.parse(res);
                    notification(res);
                    window.location.href = window.location.href;
                }
            });

        })
        </script>

    </body>

    </html>