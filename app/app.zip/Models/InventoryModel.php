<?php

namespace App\Models;

use CodeIgniter\Model;

class InventoryModel extends Model
{
    protected $DBGroup          = 'default';
    protected $table            = 'hardware_serial';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;
    protected $returnType       = 'array';
    protected $useSoftDeletes   = false;
    protected $protectFields    = true;
    protected $allowedFields    = [];

    // Dates
    protected $useTimestamps = false;
    protected $dateFormat    = 'datetime';
    protected $createdField  = 'created_at';
    protected $updatedField  = 'updated_at';
    protected $deletedField  = 'deleted_at';

    // Validation
    protected $validationRules      = [];
    protected $validationMessages   = [];
    protected $skipValidation       = false;
    protected $cleanValidationRules = true;

    // Callbacks
    protected $allowCallbacks = true;
    protected $beforeInsert   = [];
    protected $afterInsert    = [];
    protected $beforeUpdate   = [];
    protected $afterUpdate    = [];
    protected $beforeFind     = [];
    protected $afterFind      = [];
    protected $beforeDelete   = [];
    protected $afterDelete    = [];


    public function data_stock_manage_management_list(){
        $rs = $this->db
            ->table('hardware_serial')
            ->select('hardware_serial.*,master_hardware_category.hw_name')
            ->join('master_hardware_category', 'master_hardware_category.id=hardware_serial.hw_id and master_hardware_category.row_status = 1', 'left')
            ->where(['hardware_serial.row_status' => 1])
            ->get()->getResult();
        
        return $rs;
    }


    public function data_current_row($row_cond_array) {
		return $this->where($row_cond_array)->get()->getRow();
	}

    public function data_update($id, $update_array){
        return $this->db->table('hardware_serial')->where(["hw_sl_id" => $id])->set($update_array)->update();
    }

    public function data_remove($table_id, $cond){
        $this->db->table($table_id)->where($cond)->delete();
        return true;
    }
}
