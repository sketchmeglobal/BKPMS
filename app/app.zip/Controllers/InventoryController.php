<?php

namespace App\Controllers;

use App\Controllers\BaseController;

use App\Models\PermissionModel;
// use App\Models\MessageModel;
use App\Models\InventoryModel;
use App\Models\ChangeManagementModel;


class InventoryController extends BaseController
{
    private $permission = '';
   private $inv_obj = '';
   private $cm_obj = '';
   private $session_exists = 1;
   private $table_name = '';

   public function __construct(){

      $this->permission = new PermissionModel();
      $this->inv_obj = new InventoryModel();
      $this->cm_obj = new ChangeManagementModel();

      $session = session();
      if($session->logged_in == true and !empty($session->get('id'))) {
          $this->session_exists = 1;
      }else{
          $this->session_exists = 0;
      }
   }
   public function check_session(){
    if(!$this->session_exists){
       return redirect()->to(base_url('login'));
    }
 }
    public function sm_list(){
        // ------INITIALLISATION------
        $session = session();
        $uid = $session->get('id');
        $ul = $session->get('user_level');
        // ------INITIALLISATION ENDS------

        // ------PERMISSION------
        $this->check_session();
        $approved_menu = $this->permission->fetch_navbar($ul,$uid);
        //   print_r($approved_menu);
            #stop direct URL access
        if(!in_array('cm-list', array_column($approved_menu, 'menu_slug'))){
            return redirect()->to(base_url('login?st=1'));
        }

        
        // ADD NEW
        $data['validation_status'] = $data['notification_status'] = 0;
        $data['notify_type'] = ''; 
        $data['notify_msg'] = '';
        if($this->request->getVar('sm_form')){
            // echo "<pre>"; print_r($this->request->getVar()); die;
            $cm_add_rule = [
                'device_id' => 'required',
                'device_serial_no' => 'required'
            ];

            if (!$this->validate($cm_add_rule)) {

                /* $data['validation_status'] = 1;
                $data['validation'] = $this->validator; */

            }

            $data['notification_status'] = 1;

                $insert_array = array();
                foreach($this->request->getVar() as $key => $value){
                    
                    if($key == 'sm_form'){ continue; }
                    $value = ($value == '') ? null : $value;
                    if($key == 'deviceMetaData'){
                        $is_empty = 0;
                        foreach ($value as $valuedeviceMetaData) {
                            if(empty($valuedeviceMetaData['label']) && empty($valuedeviceMetaData['value'])){
                                $is_empty = 1;
                            }
                        }

                        if(!$is_empty){
                            $value = json_encode($value);
                        }else{
                            if($key == 'deviceMetaData'){ continue; }
                        }
                    }
                    
                    

                    $insert_array[$key] = $value;

                }
                if(!empty($insert_array)){
                    if($this->cm_obj->data_insert('hardware_serial', $insert_array)){
                        $data['notify_type'] = 'success';
                        $data['notify_msg'] = 'Data Inserted Successfully';
                    }else{
                        $data['notify_type'] = 'error';
                        $data['notify_msg'] = 'Data Insertion Error';
                    }
                }

                echo json_encode($data, JSON_HEX_QUOT | JSON_HEX_TAG);
                exit();
                

        }
        if($this->request->getVar('sm_form_edit')){
            // echo "<pre>"; print_r($this->request->getVar()); die;
            $cm_add_rule = [
                'device_id' => 'required',
                'device_serial_no' => 'required'
            ];

            if (!$this->validate($cm_add_rule)) {

                /* $data['validation_status'] = 1;
                $data['validation'] = $this->validator; */

            }

            $data['notification_status'] = 1;

                $update_array = array();
                foreach($this->request->getVar() as $key => $value){
                    
                    if($key == 'sm_form_edit'){ continue; }
                    if($key == 'pk_id'){ continue; }
                    $value = ($value == '') ? null : $value;
                    if($key == 'deviceMetaData'){
                        $is_empty = 0;
                        foreach ($value as $valuedeviceMetaData) {
                            if(empty($valuedeviceMetaData['label']) && empty($valuedeviceMetaData['value'])){
                                $is_empty = 1;
                            }
                        }

                        if(!$is_empty){
                            $value = json_encode($value);
                        }else{
                            if($key == 'deviceMetaData'){ continue; }
                        }
                    }
                    
                    

                    $update_array[$key] = $value;

                }
                if(!empty($update_array)){
                    $id = $this->request->getVar('pk_id');
                    if($this->inv_obj->data_update($id, $update_array)){
                        $data['notify_type'] = 'success';
                        $data['notify_msg'] = 'Data Updated Successfully';
                    }else{
                        $data['notify_type'] = 'error';
                        $data['notify_msg'] = 'Data Insertion Error';
                    }
                }

                echo json_encode($data, JSON_HEX_QUOT | JSON_HEX_TAG);
                exit();
                

        }
        $data['page_title'] = "Stock Management || " . COMPANY_SHORT_NAME;
        $data['meta_tag'] = '<meta content="Baazar Kolkata, Sketch Me Global" name="keywords"><meta content="Baazar Kolkata, Sketch Me Global" name="description">';
        $data['approved_menu'] = $this->permission->fetch_navbar($ul, $uid);
        $row_cond = array(
            'row_status' => 1
        );
        $data['sm_list'] = $this->inv_obj->data_stock_manage_management_list();
    
        // $data['data_last_row'] = $this->cm_obj->data_last_row($row_cond);
        $data['inventory_category_list'] = $this->cm_obj->data_batch($table='master_hardware_category',$row_cond);
        // $data['project_inititor'] = $uid;
        // echo "<pre>"; print_r($data['inventory_category_list']); die;

        return view('inventory/stock_management_list', $data);
    }
    public function ajax_edit_sm_fetch(){
        $pid = $this->request->getVar('pid');


        $result =  $this->inv_obj->data_current_row(['hw_sl_id'=>$pid,'row_status'=>1]);

        if(is_null($result )){
            $data['notification_status'] = 1;
            $data['notify_type'] = 'error';
            $data['notify_msg'] = 'Data Not  Found';
            echo json_encode($data, JSON_HEX_QUOT | JSON_HEX_TAG);
            exit();
        }

        echo json_encode($result, JSON_HEX_QUOT | JSON_HEX_TAG);
        exit();
    }

    public function ajax_remove_sm_list(){
    
        $pid = $this->request->getPost('pid');
        $remove_cond = array(
            'hw_sl_id' => $pid
        );
        $data = $this->inv_obj->data_remove('hardware_serial',$remove_cond);
        echo json_encode($data, JSON_HEX_QUOT | JSON_HEX_TAG);
        exit();

   }
}


